const config = {
  basename: '/',
  defaultPath: '/',
  fontFamily: `'Poppins', sans-serif`,
  borderRadius: 12
};

export default config;
