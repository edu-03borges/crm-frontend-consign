import { toast } from 'react-toastify';

export default toast;