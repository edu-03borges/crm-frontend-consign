import logo from 'assets/images/logo.png';

const Logo = () => {
  return (
    <>
      <img src={logo} alt="Leads" width="120" />
    </>
  );
};

export default Logo;
